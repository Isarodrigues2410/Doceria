const numero1= document.getElementById ("numero1");
const numero2= document.getElementById ("numero2");
const numero3= document.getElementById ("numero3");
const numero4= document.getElementById ("numero4");

const btnAdd = document.getElementById ("btnAdd");
const qtd = document.getElementById ("qtd");
const vll = document.getElementById ("vll");

function calculo() {
    totalQtd = Number(numero1.value) + Number(numero2.value) + Number(numero3.value) + Number(numero4.value);
    qtd.innerHTML = totalQtd;

    totalPreco = Number(numero1.value * 12.00) + Number(numero2.value * 8.00) + Number(numero3.value * 16.00) + Number(numero4.value * 8.00);
    vll.innerHTML = totalPreco;
}

btnAdd.addEventListener("click", calculo);